require('fastestsmallesttextencoderdecoder');

module.exports = {
  TextEncoder,
  TextDecoder
};
