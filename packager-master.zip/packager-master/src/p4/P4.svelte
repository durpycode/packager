<script>
  import {_} from '../locales/';
  import {fade} from 'svelte/transition';
  import ComplexMessage from './ComplexMessage.svelte';
  import Section from './Section.svelte';
  import SelectProject from './SelectProject.svelte';
  import SelectLocale from './SelectLocale.svelte';
  import SelectTheme from './SelectTheme.svelte';
  import Progress from './Progress.svelte';
  import Modals from './Modals.svelte';
  import {progress, theme} from './stores';
  import {isSupported, isSafari, isStandalone} from './environment';
  import version from '../build/version-loader!';
  import {LONG_NAME, FEEDBACK_PRIMARY, FEEDBACK_SECONDARY, ACCENT_COLOR, SOURCE_CODE, WEBSITE} from '../packager/brand';

  let projectData;

  const darkMedia = window.matchMedia('(prefers-color-scheme: dark)');
  let systemTheme = darkMedia.matches ? 'dark' : 'light';
  if (darkMedia.addEventListener) {
    darkMedia.addEventListener('change', () => {
      systemTheme = darkMedia.matches ? 'dark' : 'light';
    });
  }
  $: document.documentElement.setAttribute('theme', $theme === 'system' ? systemTheme : $theme);

  let modalVisible = false;

  let title = '';
  $: document.title = projectData && title ? `${title} - ${LONG_NAME}` : LONG_NAME;

  const getPackagerOptionsComponent = () => import(
    /* webpackChunkName: "packager-options-ui" */
    './PackagerOptions.svelte'
  );
  // We know for sure we will need this component very soon, so start loading it immediately.
  getPackagerOptionsComponent();
</script>

<style>
  :root {
    font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
  }
  :global([theme="dark"]) {
    background: #111;
    color: #eee;
    color-scheme: dark;
  }
  :global(a) {
    color: blue;
  }
  :global([theme="dark"] a) {
    color: #56b2ff;
  }
  :global(a:active) {
    color: red;
  }
  :global(input[type="text"]),
  :global(input[type="number"]),
  :global(textarea) {
    padding: 2px;
  }
  :global(input[type="text"]),
  :global(input[type="number"]),
  :global(textarea),
  :global(.is-not-safari select) {
    background-color: white;
    color: black;
    border: 1px solid rgb(160, 160, 160);
    border-radius: 2px;
  }
  :global(.is-not-safari select:hover) {
    border-color: rgb(30, 30, 30);
  }
  :global([theme="dark"] input[type="text"]),
  :global([theme="dark"] input[type="number"]),
  :global([theme="dark"] textarea),
  :global([theme="dark"] .is-not-safari select) {
    background-color: #333;
    color: white;
    border-color: #888;
  }
  :global([theme="dark"] .is-not-safari select:hover) {
    border-color: #bbb;
  }
  :global(p), :global(h1), :global(h2), :global(h3) {
    margin: 12px 0;
  }
  :global(summary) {
    cursor: pointer;
  }
  :global(input) {
    font-size: 0.8em;
  }
  main {
    padding-bottom: 10px;
  }
  footer {
    text-align: center;
  }
  footer > div {
    margin-top: 12px;
  }
  .footer-spacer {
    margin: 0 3px;
  }
</style>

<Modals bind:modalVisible={modalVisible} />

<main aria-hidden={modalVisible} class:is-not-safari={!isSafari}>
  <Section accent={ACCENT_COLOR}>
    <div>
      <h1>{LONG_NAME}</h1>
      {#if version}
        <p><i>{version}</i> - <a href={WEBSITE}>Online version</a></p>
      {/if}
      <p>{$_('p4.description1')}</p>
      <p>
        <ComplexMessage
          message={$_('p4.description2')}
          values={{
            embedding: {
              text: $_('p4.description2-embedding'),
              href: 'https://docs.turbowarp.org/embedding'
            }
          }}
        />
      </p>
      <p>
        <ComplexMessage
          message={$_('p4.description3')}
          values={{
            // These placeholders are named this way for legacy reasons.
            onScratch: {
              text: $_('p4.description3-on').replace('{brand}', FEEDBACK_PRIMARY.name),
              href: FEEDBACK_PRIMARY.link
            },
            onGitHub: {
              text: $_('p4.description3-on').replace('{brand}', FEEDBACK_SECONDARY.name),
              href: FEEDBACK_SECONDARY.link
            }
          }}
        />
      </p>
    </div>
  </Section>

  {#if isSupported}
    <SelectProject bind:projectData />
  {:else}
    <Section accent="#4C97FF">
      <h2>Browser not supported</h2>
      <p>Please update your browser to use this site.</p>
    </Section>
  {/if}

  {#if projectData}
    {#await getPackagerOptionsComponent()}
      <Section center>
        <Progress text="Loading interface..." />
      </Section>
    {:then { default: PackagerOptions }}
      <div in:fade>
        <PackagerOptions
          projectData={projectData}
          bind:title={title}
        />
      </div>
    {:catch}
      <Section center>
        Something went wrong, please refresh and try again.
      </Section>
    {/await}
  {/if}

  {#if $progress.visible}
    <Section center>
      <Progress progress={$progress.progress} text={$progress.text} />
    </Section>
  {/if}

  <footer>
    <div>
      {#if !isStandalone}
        <a href="privacy.html">{$_('p4.privacy')}</a>
        <span class="footer-spacer">-</span>
      {/if}
      <a href={FEEDBACK_PRIMARY.link}>{$_('p4.feedback')}</a>
      <span class="footer-spacer">-</span>
      <a href={SOURCE_CODE}>{$_('p4.sourceCode')}</a>
    </div>
    <div>
      <a href="https://docs.turbowarp.org/packager">{$_('p4.documentation')}</a>
    </div>
    <div>
      <a href="https://fosshost.org/">{$_('p4.fosshost')}</a>
    </div>
    <div>
      <SelectTheme />
    </div>
    <div>
      <SelectLocale />
    </div>
  </footer>
</main>
